import { useState } from 'react';
import { s } from './style.js';
import IOSDevice from './components/IOSDevice.jsx';
import SplashScreen from './components/SplashScreen.jsx';
import { addListingToCart, getCartQuantity } from './cart.js';
import Checkout from './screens/Checkout.jsx';
import MonoMarket from './screens/MonoMarket.jsx';
import ProductDetail from './screens/ProductDetail.jsx';
import { APP_SCREENS, getInitialScreen, openCheckout, openProductDetail, returnFromCheckout, returnToMarket } from './appFlow.js';

export default function App() {
  const [flow, setFlow] = useState(() => ({
    screen: getInitialScreen(),
    selectedListing: null,
  }));
  const [cartItems, setCartItems] = useState([]);

  const isProductDetail = flow.screen === APP_SCREENS.productDetail;
  const isCheckout = flow.screen === APP_SCREENS.checkout;
  const cartCount = getCartQuantity(cartItems);
  const addToCart = (listing, quantity = 1) => setCartItems((current) => addListingToCart(current, listing, quantity));
  const handleOpenCart = () => setFlow((flow) => openCheckout(flow));
  const handleCloseCheckout = () => setFlow((flow) => returnFromCheckout(flow));

  return (
    <div style={s("min-height:100vh;padding:28px 24px 46px;box-sizing:border-box;display:flex;align-items:flex-start;justify-content:center")}>
      <IOSDevice>
        <SplashScreen />
        {isCheckout ? (
          <Checkout cartItems={cartItems} onBack={handleCloseCheckout} />
        ) : isProductDetail ? (
          <ProductDetail
            listing={flow.selectedListing}
            onBack={() => setFlow(returnToMarket())}
            cartCount={cartCount}
            onAddToCart={(quantity) => addToCart(flow.selectedListing, quantity)}
            onOpenCart={handleOpenCart}
          />
        ) : (
          <MonoMarket onOpenProduct={(listing, trigger) => setFlow(openProductDetail(listing, trigger))} onOpenCart={handleOpenCart} cartCount={cartCount} />
        )}
      </IOSDevice>
    </div>
  );
}
