import assert from 'node:assert/strict';
import test from 'node:test';
import {
  APP_SCREENS,
  getInitialScreen,
  getProductOpenTriggers,
  openCheckout,
  openProductDetail,
  returnFromCheckout,
  returnToMarket,
} from './appFlow.js';

test('app flow starts on mono market and opens 11a product detail from every listing trigger', () => {
  const listing = { id: 'f12', cta: 'Buy', name: 'Cassette Walkman + 12 tapes' };

  assert.equal(getInitialScreen(), APP_SCREENS.market);
  assert.deepEqual(getProductOpenTriggers(), ['listing', 'Buy', 'Bid', 'Offer']);

  const detailState = openProductDetail(listing, 'Offer');

  assert.equal(detailState.screen, APP_SCREENS.productDetail);
  assert.equal(detailState.productDetailVariant, '11a');
  assert.equal(detailState.selectedListing, listing);
  assert.equal(detailState.trigger, 'Offer');
  assert.deepEqual(returnToMarket(), { screen: APP_SCREENS.market, selectedListing: null });
});

test('app flow opens checkout from the current screen and returns to the previous screen', () => {
  const listing = { id: 'f0', cta: 'Buy', name: 'Vintage Polaroid SX-70 - tested' };
  const detailState = openProductDetail(listing, 'Buy');
  const checkoutState = openCheckout(detailState);

  assert.equal(APP_SCREENS.checkout, 'checkout');
  assert.equal(checkoutState.screen, APP_SCREENS.checkout);
  assert.equal(checkoutState.selectedListing, listing);
  assert.equal(checkoutState.checkoutReturnScreen, APP_SCREENS.productDetail);

  assert.deepEqual(returnFromCheckout(checkoutState), {
    screen: APP_SCREENS.productDetail,
    selectedListing: listing,
    trigger: 'Buy',
    productDetailVariant: '11a',
    checkoutReturnScreen: null,
  });
});
