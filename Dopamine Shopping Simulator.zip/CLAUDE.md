# Yoink — Dopamine Shopping Sim

Main design: `Yoink Home Directions.dc.html` (option board; turns stack newest-on-top: t8 mono marketplace w/ infinite scroll, t7 white+plum, t6 purple, t5 aubergine, t4 marigold, t3 Market Teal, t2 color palettes, t1 the 3 original directions). Children: `Mochi.dc.html` (mascot), `PaletteCard.dc.html` (palette vignette), `ios-frame.jsx` (device frame).

## Infinite scroll (turn 8 / 8a)
Logic class holds `state.feed8` + `feedEndRef`. `makeFeed(start,count)` generates cycling listings; `armInfinite()` (called from componentDidMount, retries until the sentinel ref + its nearest overflow:auto ancestor exist) attaches a scroll listener that calls `loadMore()` near the bottom (throttled 200ms, cap 240). NOTE: dc_js_str_replace hot-reloads WITHOUT remount, so componentDidMount/armInfinite only re-run on a full reload — reload the user view to test scroll.
- Turn 8 "mono" palette: logo + Buy/Bid/Offer = #6A5ACD ONLY; everything else #171326 (black) / white / #F5F3FF wash. No header Sell pill, no "Got clutter" promo (center nav Sell FAB kept).

## Design system
- Fonts: Fredoka (display) + Nunito (UI). Icons: Material Symbols Rounded via `.mi` class.
- Original "candy" palette: pink #FF3D9A, purple #8B5CF6, coin-gold #FFC700, teal #10B5A0, coral #FF6B3D, ink #1E1233.
- "Market Teal / Papaya" palette (turn 3 — current pick, replaced the earlier Ion Mint in 3a & 3b): deep-teal brand frame+nav #063A3A, papaya buy/deals/CTA #FF8A3D, warm off-white surfaces #FFF7EA, bright teal fresh/saved/selected #00C7B2, near-black ink #101312.

## Standalone / offline HTML export recipe (DC -> single file)
support.js loads deps at runtime the bundler can't see. To export offline-safe:
1. Copy the entry .dc.html. In <head>, BEFORE `<script src="./support.js">`, add these (bundler inlines them; support.js skips its CDN load when window.React/ReactDOM/Babel already exist): react@18.3.1 umd, react-dom@18.3.1 umd, @babel/standalone@7.29.0 (exact versions live in support.js REACT_URL/REACT_DOM_URL/BABEL_URL).
2. Embed each sibling (ios-frame.jsx, Mochi.dc.html, PaletteCard.dc.html, ...) as base64 in `<script type="text/plain" id="dep-...">`, plus a fetch shim (before support.js) that serves `./ios-frame.jsx` / `./<Name>.dc.html` from the base64 and short-circuits `fetch(location.href)` -> empty 200.
3. Subset Material Symbols with `&icon_names=...` on its Google Fonts link. Must include EVERY ligature used. Current full set: add, add_shopping_cart, bolt, casino, check, expand_more, favorite, home, local_fire_department, lock, notifications, notifications_active, person, photo_camera, redeem, search, sell, shopping_bag, shopping_cart, star, timer, tune, visibility, bookmark.
4. Add `<template id="__bundler_thumbnail" data-bg-color="#1b1226">` splash.
5. super_inline_html -> verify `externalScripts.length === 0` via eval_js -> present_fs_item_for_download.
